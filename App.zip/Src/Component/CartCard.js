import { View, Text } from "react-native";
import React from "react";

export default function CartCard() {
  return (
    <View>
      <Text>CartCard</Text>
    </View>
  );
}
