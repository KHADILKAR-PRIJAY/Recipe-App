export default {
  apiKey: "AIzaSyCvXEZeAhZFOkYnTc0uyZoK5l_jKG3jc8s",
  authDomain: "foodrecipe-1c579.firebaseapp.com",
  projectId: "foodrecipe-1c579",
  storageBucket: "foodrecipe-1c579.appspot.com",
  messagingSenderId: "35233988661",
  appId: "1:35233988661:web:5f99337764568de4c5f17c",
  measurementId: "G-NEEEMN2ZRG",
};
